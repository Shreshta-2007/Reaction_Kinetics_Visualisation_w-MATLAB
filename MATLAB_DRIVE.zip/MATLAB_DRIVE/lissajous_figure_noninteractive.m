% Lissajous Figure Plot (Non-Interactive)

% Parameters
A = 1; % Amplitude in x
B = 1; % Amplitude in y
a = 5; % Frequency in x
b = 4; % Frequency in y
delta = pi/2; % Phase Difference

% Time vector
t = linspace(0, 2*pi, 1000);

% Parametric Equations
x = A * sin(a*t + delta);
y = B * sin(b*t);

% Plot
figure;
plot(x, y, 'b', 'LineWidth', 2);
grid on;
axis equal;

xlabel('x(t)');
ylabel('y(t)');
title(sprintf('Lissajous Figure: a=%d, b=%d, \\delta=%.2f', a, b, delta));
