function interactiveLissajous()

% Create a figure window
f = figure('Name','Interactive Lissajous Figure', ...
           'NumberTitle','off', ...
           'Position',[100,100,800,600]);

% Create axes for plotting
ax = axes('Parent',f,'Position',[0.4,0.8,0.6,1.2]);
grid on;

% Default values
A = 1;
B = 1;
a = 3;
b = 2;
delta = pi/2;

% Time vector
t = linspace(0, 2*pi, 1000);

% Initial plot
x = A * sin(a*t + delta);
y = B * sin(b*t);
h = plot(ax, x, y, 'b', 'LineWidth', 2);

title(ax,'Lissajous Figure');
xlabel(ax,'x(t)');
ylabel(ax,'y(t)');
axis(ax,'equal');

%% Slider for a (frequency in x)
uicontrol('Style','text','Position',[100,200,120,20], ...
          'String','Frequency a (x)');
sa = uicontrol('Style','slider','Min',1,'Max',10,'Value',a, ...
               'Position',[100,180,120,20], ...
               'Callback',@updatePlot);

%% Slider for b (frequency in y)
uicontrol('Style','text','Position',[300,200,120,20], ...
          'String','Frequency b (y)');
sb = uicontrol('Style','slider','Min',1,'Max',10,'Value',b, ...
               'Position',[300,180,120,20], ...
               'Callback',@updatePlot);

%% Slider for delta (phase shift)
uicontrol('Style','text','Position',[500,200,120,20], ...
          'String','Phase \delta');
sdelta = uicontrol('Style','slider','Min',0,'Max',2*pi,'Value',delta, ...
                   'SliderStep',[0.01 0.1], ...
                   'Position',[500,180,120,20], ...
                   'Callback',@updatePlot);

%% Callback function
    function updatePlot(~,~)
        a = get(sa,'Value');
        b = get(sb,'Value');
        delta = get(sdelta,'Value');

        x = A * sin(a*t + delta);
        y = B * sin(b*t);

        set(h,'XData',x,'YData',y);
        title(ax, sprintf('Lissajous Figure: a=%.2f, b=%.2f, \\delta=%.2f', a, b, delta));
    end

end