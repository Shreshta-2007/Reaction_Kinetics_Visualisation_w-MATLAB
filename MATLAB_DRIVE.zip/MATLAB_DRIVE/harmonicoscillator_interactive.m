% Damped Harmonic Oscillator

clc;
clear;
close all;

% Parameters
m = 1;          % mass (kg)
c = 0.5;        % damping coefficient (Ns/m)
k = 4;          % spring constant (N/m)

% Time span
t = linspace(0, 20, 1000);

% Initial conditions
x0 = 1;         % initial displacement (m)
v0 = 0;         % initial velocity (m/s)

% Derived quantities
wn = sqrt(k/m);                     % natural frequency
zeta = c/(2*sqrt(k*m));             % damping ratio
wd = wn*sqrt(1 - zeta^2);           % damped frequency

% Solution (underdamped case)
A = x0;
B = (v0 + zeta*wn*x0)/wd;

x = exp(-zeta*wn*t) .* (A*cos(wd*t) + B*sin(wd*t));

% Plot
figure;
plot(t, x, 'c', 'LineWidth', 2);
grid on;

title('Damped Oscillator');
xlabel('Time (s)');
ylabel('Displacement (m)');

xlim([0 20]);
ylim([-0.8 1]);