function interactive_damped_oscillator()

clc;
close all;

% Time
t = 0:0.01:20;

% Create figure
f = figure('Position',[200 200 800 500],...
           'Name','Damped Harmonic Oscillator',...
           'NumberTitle','off');

% Plot
ax = axes('Position',[0.1 0.35 0.8 0.6]);
h = plot(t, zeros(size(t)),'LineWidth',2);
grid on
xlabel('Time (s)')
ylabel('Displacement (m)')
title('Interactive Damped Harmonic Oscillator')

% -------- Sliders --------

% Mass
uicontrol('Style','text','Position',[50 140 100 20],'String','Mass (m)');
m_slider = uicontrol('Style','slider','Min',0.5,'Max',5,'Value',1,...
    'Position',[150 140 200 20],'Callback',@updatePlot);

% Spring constant
uicontrol('Style','text','Position',[50 110 100 20],'String','Spring (k)');
k_slider = uicontrol('Style','slider','Min',1,'Max',10,'Value',4,...
    'Position',[150 110 200 20],'Callback',@updatePlot);

% Damping
uicontrol('Style','text','Position',[50 80 100 20],'String','Damping (c)');
c_slider = uicontrol('Style','slider','Min',0,'Max',4,'Value',0.8,...
    'Position',[150 80 200 20],'Callback',@updatePlot);

% Initial displacement
uicontrol('Style','text','Position',[50 50 100 20],'String','Initial x0');
x0_slider = uicontrol('Style','slider','Min',0,'Max',2,'Value',1,...
    'Position',[150 50 200 20],'Callback',@updatePlot);

% Initial velocity
uicontrol('Style','text','Position',[400 50 120 20],'String','Initial v0');
v0_slider = uicontrol('Style','slider','Min',-2,'Max',2,'Value',0,...
    'Position',[520 50 200 20],'Callback',@updatePlot);

% Regime text
regime_text = uicontrol('Style','text',...
    'Position',[400 100 300 30],...
    'FontSize',12,...
    'String','');

% Initial plot
updatePlot();

% -------- Update Function --------
function updatePlot(~,~)

    m = m_slider.Value;
    k = k_slider.Value;
    c = c_slider.Value;
    x0 = x0_slider.Value;
    v0 = v0_slider.Value;

    wn = sqrt(k/m);
    zeta = c/(2*sqrt(m*k));

    if zeta < 1
        wd = wn*sqrt(1 - zeta^2);
        x = exp(-zeta*wn*t) .* ...
            (x0*cos(wd*t) + ((v0 + zeta*wn*x0)/wd)*sin(wd*t));
        regime = 'Underdamped';
    elseif zeta == 1
        x = (x0 + (v0 + wn*x0).*t).*exp(-wn*t);
        regime = 'Critically Damped';
    else
        x = x0*exp(-wn*t);
        regime = 'Overdamped';
    end

    set(h,'YData',x);
    title(['Damped Harmonic Oscillator - ' regime])

    regime_text.String = ['Regime: ' regime];

    drawnow;
end

end
